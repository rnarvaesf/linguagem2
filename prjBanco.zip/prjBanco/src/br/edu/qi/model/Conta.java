/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.qi.model;

/**
 *
 * @author Alunos
 */
public class Conta {
    protected double saldo;
    private Correntista correntista;

    public Conta(double saldo, Correntista correntista) {
        this.saldo = saldo;
        this.correntista = correntista;
    }
    public Conta (Correntista correntista)    {
        this.correntista = correntista;
        
    }
    public double getSaldo() {
        return this.saldo;
    }
    public Correntista getCorrentista() {
        return this.correntista;
    }
    public boolean retirar(double valor)  {
        if (this.getSaldo() <= 0 || 
            this.getSaldo() < valor)
            return false;
        
        this.saldo -=  valor;
        return true;
    }
    public void depositar(double valor)  {
        this.saldo +=  valor;
    }

    @Override
    public String toString() {
        return this.correntista.getNome()+
               "  tem R$ " + this.getSaldo();
    }
    
}
