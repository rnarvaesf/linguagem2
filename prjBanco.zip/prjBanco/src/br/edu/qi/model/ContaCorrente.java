/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.qi.model;

/**
 *
 * @author Alunos
 */
public class ContaCorrente extends Conta {
    private double limite;
    public ContaCorrente(double saldo, 
            Correntista correntista,double limite) {
        super(saldo, correntista);
        this.limite=limite;
    }
    public void depositar(Cheque valor){
        super.depositar(valor.getValor());
    } 

    @Override
    public boolean retirar(double valor) {
        //  2000   <=      500         +    1000
        if (valor <= (super.getSaldo() + this.limite) 
            )
            return super.retirar(valor);
        
        return false;
        
    }
    
}
