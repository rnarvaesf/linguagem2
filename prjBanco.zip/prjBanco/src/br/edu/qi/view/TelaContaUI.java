/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.qi.view;

import br.edu.qi.controller.TelaContaCtr;
import br.edu.qi.model.Cheque;
import br.edu.qi.model.Conta;
import br.edu.qi.model.ContaCorrente;
import br.edu.qi.model.Correntista;

/**
 *
 * @author Alunos
 */
public class TelaContaUI {
    public static void main(String[] args) {
        TelaContaCtr ctr = new TelaContaCtr();

       //passo1
       ctr.criarCtaCorrentista(11, "Rodrigo", 25);
       
        
        //passo4
        ctr.mostrarDadosCta();
        
        try {
            //passo6 - retirar 26 da cta 1
            ctr.saque(25);
            
            ctr.mostrarDadosCta();

            //retirar 200 da cta2
            ctr.saque(200);
        
         } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        
    }
}
