/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.qi.controller;

import br.edu.qi.model.Conta;
import br.edu.qi.model.Correntista;

/**
 *
 * @author Alunos
 */
public class TelaContaCtr {
    
    private Conta conta;
    private Correntista correntista;
    
    public void criarCtaCorrentista(long cpf,
                                    String nome,
                                    double saldo)
    {
        this.correntista=new Correntista(cpf, nome);
        this.conta = new Conta(saldo, correntista);
        
    }
    public void mostrarDadosCta()
    {
        System.out.println("---Dados da Cta do Cliente---");
        System.out.println("CPF: "+this.correntista.getCpf());
        System.out.println(this.conta);
    }
    public void saque(double valor) throws Exception
    {
        boolean retorno = this.conta.retirar(valor);
        if (!retorno)
            throw new Exception("Não existe saldo para saque");
            
    }
    
}
