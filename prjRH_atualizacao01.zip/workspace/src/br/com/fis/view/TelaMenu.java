package br.com.fis.view;

import br.com.fis.utl.Teclado;

public class TelaMenu {

	public static int montaMenu()
	{
		System.out.println("---Menu principal---");
		System.out.println("1 � Departamento");
		System.out.println("2 � Funcion�rio");
		System.out.println("3 � Gerentes");
		System.out.println("99 - Sair");
	
		return Teclado.lerInt();
		
	}
	
}
