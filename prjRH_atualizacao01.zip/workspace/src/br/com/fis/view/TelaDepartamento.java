package br.com.fis.view;

import br.com.fis.model.Departamento;
import br.com.fis.model.DepartamentoBO;
import br.com.fis.utl.Teclado;

public class TelaDepartamento {

	private static Departamento depto;
	private static final String MSG_SAVE="Grava��o com sucesso";
	
	public static void solicitarDados() 
	{
		depto= new Departamento();		
		System.out.println("Informe o nro do Depto: ");
		depto.setNumero(Teclado.lerInt());
		
		System.out.println("Informe o nome do depto: ");
		depto.setNome(Teclado.lerString());
		
		
	}
	public static void save(DepartamentoBO bo) 
	{
		try {
			bo.save(depto);
			System.out.println(MSG_SAVE);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		}
		
	}
}
