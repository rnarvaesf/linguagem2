package br.com.fis.view;

import br.com.fis.model.DepartamentoBO;
import br.com.fis.model.EmpregadoBO;

public class TesteCadastroEmpregados {

	public static void main(String[] args) {
		DepartamentoBO deptoBo = new DepartamentoBO();
		EmpregadoBO empBo = new EmpregadoBO();
		
		int opcao=0;
		do {
			//Monta menu
			opcao=TelaMenu.montaMenu();
			
			switch (opcao) {
			case 1:
				TelaDepartamento.solicitarDados();
				TelaDepartamento.save(deptoBo);
				
				break;
			case 2:
				TelaEmpregado.solicitarDados();
				TelaEmpregado.save(empBo);
			default:
				break;
			}
			
		} while (opcao!=99);
		System.out.println("Fim da execu��o!");
		

	}
}
