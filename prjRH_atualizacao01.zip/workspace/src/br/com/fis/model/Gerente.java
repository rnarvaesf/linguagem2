package br.com.fis.model;

public class Gerente extends Empregado {
	private Departamento departamento;
	
	public Gerente(long cpf, String nome) {
		super(cpf, nome);
	}
	public Gerente() {
		super(0,"");
	}
	public Departamento getDepartamento() {
		return departamento;
	}
	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	
	
	
}
