package br.com.fis.model;

import java.util.ArrayList;

public class EmpregadoBO {
	private static final String MSG_EMPLOYEE_EXIST="Funcion�rio j� cadastrado!";
	private ArrayList<Empregado> arrEmpregados;
	
	public EmpregadoBO() {
		this.arrEmpregados = new ArrayList<Empregado>();
	}
	
	public void save(Empregado empregado) {
		for(Empregado emp : this.arrEmpregados)
		{
			if (emp.getCpf()==empregado.getCpf())
				throw new RuntimeException(MSG_EMPLOYEE_EXIST);
			
		}
		this.arrEmpregados.add(empregado);
	}
	public String getAll() 
	{
		String ret = null;
		for(Empregado emp : this.arrEmpregados)
		{
			ret +=ret!=null ? ", "+emp : emp;
		}
		return ret;
		
	}
}
