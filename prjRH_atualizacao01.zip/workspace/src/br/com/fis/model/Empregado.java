package br.com.fis.model;

public class Empregado {
	protected long cpf;
	protected String nome;
	
	public Empregado() {
		// TODO Auto-generated constructor stub
	}
	public long getCpf() {
		return cpf;
	}
	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Empregado(long cpf, String nome) {
		
		this.cpf = cpf;
		this.nome = nome;
	}
	@Override
	public String toString() {
		return "Funcion�rio "+this.getNome()+
				" CPF "+this.getCpf();
	}
	
}
