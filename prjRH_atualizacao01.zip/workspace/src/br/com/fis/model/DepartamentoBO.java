package br.com.fis.model;

import java.util.ArrayList;
import java.util.Iterator;

public class DepartamentoBO {

	private static final String MSG_DEPTO_EXIST="Depto j� cadastrado!";
	private String ret=null;
	
	private ArrayList<Departamento> arrDeptos;
			  
	public DepartamentoBO() {
		this.arrDeptos=
				new ArrayList<Departamento>();
	}
	public void save(Departamento depto) throws Exception {
		for(Departamento dep : this.arrDeptos)
		{
			if (dep.getNome().equals(depto.getNome()))
				throw new Exception (MSG_DEPTO_EXIST);
		}
		this.arrDeptos.add(depto);
	}
	public String getAll() throws Exception
	{		
		this.arrDeptos.forEach(dep -> {
			ret += ret!=null ? ","+dep  : dep;
		});
		return ret;
	}
}
